INSERT INTO employee (name, position, salary) VALUES ('John Doe', 'Manager', 75000);
INSERT INTO employee (name, position, salary) VALUES ('Jane Doe', 'Developer', 65000);